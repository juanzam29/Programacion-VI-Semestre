const peliculas = [
  {
    id: 1,
    titulo: "Interestelar",
    genero: "Ciencia ficción",
    anio: 2014,
    calificacion: 4.8,
    director: "Christopher Nolan",
    poster:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQogXOgYYNcvjIfUlDaDNa3vtlc4wU7_UDfnOEI35Ak8Q&s=10",
    sinopsis:
      "Un equipo de exploradores atraviesa un agujero de gusano en busca de un nuevo hogar para la humanidad."
  },

  {
    id: 2,
    titulo: "Spider-Man: Homecoming",
    genero: "Acción",
    anio: 2017,
    calificacion: 4.6,
    director: "Jon Watts",
    poster:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSL-xmaW2LsGiG9S2f8m-9g5wetT_F8ZN7UJh3hx1kp8A&s=10",
    sinopsis:
      "Peter Parker intenta equilibrar su vida escolar y sus responsabilidades como superhéroe."
  },

  {
    id: 3,
    titulo: "Toy Story",
    genero: "Animación",
    anio: 1995,
    calificacion: 4.5,
    director: "John Lasseter",
    poster:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0IEXI6ExjJAat12VkKcczRtn5CLbiFfsZc2tQsWbbgg&s=10",
    sinopsis:
      "La amistad entre Woody y Buzz se pone a prueba cuando llega un nuevo juguete a la habitación."
  },

  {
    id: 4,
    titulo: "The Conjuring",
    genero: "Terror",
    anio: 2013,
    calificacion: 4.7,
    director: "James Wan",
    poster:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR4apBQ7_x5yP2y7qBtHoce0DOM1SdkBIx8v0j2pIparg&s=10",
    sinopsis:
      "Dos investigadores paranormales reciben una llamada sobre una familia atormentada por fuerzas oscuras."
  },

  {
    id: 5,
    titulo: "La La Land",
    genero: "Comedia",
    anio: 2016,
    calificacion: 4.4,
    director: "Damien Chazelle",
    poster:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRO6ygU5xWJK9-fjKcXK74MkveWv6H7QmReIuLVgDlHzg&s=10",
    sinopsis:
      "Una pianista y un músico de jazz se conocen y empiezan una historia de amor llena de sueños."
  },

  {
    id: 6,
    titulo: "Dune",
    genero: "Ciencia ficción",
    anio: 2021,
    calificacion: 4.8,
    director: "Denis Villeneuve",
    poster:
      "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEBUSEhMWFhUWGBgYFhcWFRYXFxcVGRUXFxUYGBUYHSggGRslHRUXITEhJSkrLy4uGB8zODMtNygtLisBCgoKDg0OGhAQGi0lHyUtLS0tLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSstLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAREAuQMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAEAQIDBQYAB//EAEMQAAEDAgQCBwUFBwMCBwAAAAEAAhEDIQQSMUEFUQYTImFxgZEyobHB0RRCUuHwFSNTYnKCkqLS8QczQ2ODk7LC4v/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACsRAAICAgEDAwMEAwEAAAAAAAABAhESIQMxQVEEE2EUMvAicaHxgZHBQv/aAAwDAQACEQMRAD8AYuSpzGyYmO9bHljVyP8As9PSW6a59T4frVR4agy+Zw5AExN9ZQAIuRlTDskQ5sTBEzsTM8tl1SgyWgOaJme1MbhAAa5GV8OyRlc0AmPanYmfDZPGHpxq0nnmQACuRTcM3NGdsCN4nWfh711ag37rhFrTO+qABVyL+yNFzUaY2B1E7KR2HpkWc0H+qfcUAALkS/DAffabgW5Xvr3JXYQR/wBxvr7tUACLkY6kzq5kZrfevqJt5+5KMI2f+40jxjfxQAEuR1TDsIGVzQd+1PKyjbh25oztIidY3iPmgAVcj6tCnDoLZA/FqY257LqWGpxdzTb8UR3IAr0qMwuHYbuc3e2aN4/ND4hgDrGR3X8kARJYXLkAKuSrkAIuSrkAJCVKuhAhEqWF0IARcnQmvMAk6AT6IA5c2+l1k8dxsOrFuaWtvEwIH3nfIaqrPGQ0nq2unTNJEebyQFk+R3pHXH01q2z0HIeS7KV5w3jOJaZmoRs4PLj5gG6tuF9KHO9o9rnsf6gj3H4D6b5NgkhPpVA+mHjzCSFpGVqzmlFxdMauhOhImSJCROSIGJC5KuQA1dCcuhACrksJYQIalhKAlhMBIXQnQlhADYSwnQlhADYWd6ScWyzTaRp2iSBHdf8AV1c8Vrup0XvaBLQTfQAAkn3LyCvi6lQlx3uSZM3Wc32On0/Gm8mHOYyDex1gkZuXfHx25ojCYPMYsIgCdibkxpAAJ8lVU6o533Ph3q14c4OJGzoHmQQY9T6rN6O0mp42iHZaZc7Lq7KxwO1y4SfKAiqfDTVlwomedMQXeAVn0Q6OCn2qkOcfQDZekcMwzWgQAPBTe9ClpHlXD+IYnDvFGuxzAfZzDa2+h/NbHBVjUAeCC2L3vO1ttD4rQdLeDMxGEfLRnaM9N24cL694keay/CYb1TBfsua7wyyD7k06kY8iU433LGEkKSEkLpOAZCSE+EkIAZC5OhJCQCLksLkAOhLCdCWEwGwlhOhKAgBsJYT4QHEeL0aIJqONtYaXRtciwQNJvoGwlAQHCeOYfEEilUBI1aQWu8YOo8FZwgGmupS9Ka4bhngx2gWkTBgiNN15JXEdkajXbw8V6x04w5dgasagB2+gcCfcF5RgsznHd0dn9frdZT6nd6WnH/JBRYXODeZV3jqZp0wMsQ4EXiLa28vVGYDhJdlJBDgYM6+MhHYXhbesPXEvv3xOxM68lk5HWlQNhOl1drQKdMOgSZa4mBqZHJbTod0vdiCWdUQQNjIQ+B6PUmglpcJBBk6g6i2x5Kz6N8OZQrA0gLmHeCm12IaTsLrdNMO6nVohx6wMeB2TBdlNs3is30YxGbK7NJLQfARHumFPxnow3C4Ws8RZwGplwqVGsOaTs0nTmeai6J4UNDnaAQBtbck+PwVVbRlLFRbNGQmlqh/aVKYzgnSwJ+AU1Kq112kHnzHiNQulNHnNNdUJCSFIQkITERwkhPhJCAGQuhPhdCAHQlhOhOhAhoCcGpQE6EAVePdVcH9US0U2kucCJBJgagjn3rzfi3C63tZSQLFxMl17H8916VxTirKGGfTLC51WrBNgGhga4SSf5vcVQ4zHAdjLqNSTHo0ErnlN3o9Di4/0nnNKo5jw9ji1zTIIsQV690V4yMVQDjAeIDx38/cV55x7hIZ+8bo7YGQrXoLiOpq9qQHnKZ2zAEH1HxVqa6i5eO0wvi3Ea2fEUalQQ4lobALWhwsGVCLOgixvOywuLwbqTpa7Q22IP65LedNXjCvaA3NTrZyZ1a+QXQdwcwMHv8FiMa4OHZNuXLujUeGnchrY+LpaL7olxN1So9tR18oy7aEz53WkIErzwYd7CHCQW6EHTwPyPorXC9JnggVWz/MLeoWUod0dCkej4SoS2JhD02Y0VWtoub1YIE5LiTEk7+iz9DHGs3sAvHJrsp9QZVrwTg1XMHvo1Y0zfaH2b3jNKhLZeu7NV0iwhrMZSe6Wh7XPt7YZdo7gXZT/AGxvK8z6RcWAqOp0y4MZmgCYJJvItN9PBeo1CTudIE39ea8LfSLqjzIJzOzWkWcbgbaLocaRw8UspMuej3GH06rbZ+Q1Mm2gW16M8IxGcvMQ65E3EnS5WW6N0crTVIgDSwnxla3gPSRoe0Gm4B5IDpmDzdyCzy2bShaL3E0cri3koS1EVsR1ji/I5hNi10SCLHTYxKjhdKPNkqdERCbCmITcqBEULoTyEkIAlASwlASwgBISjmnAKLFmG/rQfoJSdKy4K5JFbTq9aOrIa5tOsXua5wa0tc0GXE20aQqjD1g57iS0yZtGu8AaBPpVGUzWqvMgGmC2ASS1zja+ogHyVZX4zQa0uYZmYJiYk+fuXI0z1ItEPSl3ZE6SgzhnMc4bty5u4nl5EIHG8WLnNf7WUg5SCG225o9nE31HOL2gmpDnhsgAwIiZjQFUlS2KT3om6VYl1bC0WwSWP17iwggnxCztHg9R3slk8s11reG9HTiI6yoWMA7IAuTuTKJxXQqtQHWUnh4H9phUpkqKRiqz6tI5arD42nyIsVE9ransi/dY+i22GczE0DSrAA7HcEbhYzFYHK9zTq0kehVRdiYzBB9GpnYS1wsbbciF6b0Y4w7qTUrPDQbNa2XSIBJt3kj+1ecNrvgB5zRoTqB47juKLwtfM4Ac4tr5z/wh0tiaclR61hcbSqCWPB9QfQheWVabsPXqGrSe2k6o4MdEdpridN2xrHctnhejTwxpoVAHa5SIE8lX/wDUjA1HUadWo3K6m1zXNOoc4BwIP3gQxwn+XvSyzWyIQ9qWimwXGQx8GzXElttJM3Ct8bxQQ1zAC6eRAvvI5clgHVXFgLgY0DthG0rQcEqhwaesIeyIubi+nIpYG2VHpuDxrarGuBBOUA2gyAGk5ZMXBUxCynD8A1/Ec8jLRoioe6rUc6SfEAu9Fo2cSoueGNqNcSY7PaE33FtlvF6PP5I/q0TkJIUhCbCZkMISQnwkhAEkJQE6EsIAQBB8WacmYXiZ80eAg8VLz1be+YJGmskbCR5kBTNWqNON1JMyOEoNc57Khyu1EuyjS9+czzVdiuHUZ7VUOPLLfyc5oVp0laKD2uqEZnfcYZJE2JJAy+PObapmCpOrtJGHd5PJcPMiD6LCmjtUu5UMwNIHssHiQXH32HkpDSHKP1um4kVA4t0jZwuo3NeRlJt3CEqbKyRc8G4gHuyU2uLmszdzmtABIPitd0Y4110030nN8pb4E7G24Cy/RjHMoPEtHaaWSXBoHam5O0HW+i1HA6w6x1myIJykEX0hJKmW9xB8R0TDMS6oHFtF2gae1ndtMGBK8+4rRa5+ZpkQLxqRb5L2bixJovLTcU3keMc/AFeVNw+0eAhWluzJy1RRcMJL6mVubKA3lEk5/gLd6uuD8Hpsc4znI0togMJhnUpzBwLnFxNxuYv4clZYHEEPJB1Nys5OzoilSL3g/SJlKs1lVhbTc7LnMgNfEgE6R71Y/wDUhrK2Fpsa8E5iIBBIDqZIJHK3vQGOxNCaOdklxElrM5JEQC0fHuQPHiz7U/q/YaYECO0bvJ75tf8ACr4zHm1s8+Y17A6nMA2cIF9t1PVoltGm9hg5iCRrIAA90HzVz0gp0w8OkS4TG/mgaRDmFgIN81r7X03v7loZptqxOENc9tUOc4l8F0k9oiYLuepWn6LYYitTGwLj4dh35Kl4PTAM7GRI01Wl4biBTq5hyGvIua13xTRnyPqa4hNIUguAeaSFochFC6FIQkhMCQBLCcAlhIYgCqeGY9tHC4iqRL+ue0DcuzS1s8u1PqrLF18jC7XkOZ2CpnUXVAGmPbe4zpIYATA8x5qZGkALFPzlj3xLwJJH3gGjyH1V9wniFIODesaDoASBJ7lk+M4RtRrGv0aHixI3B1mys8HRwlXqXMhzwAwy1wBj2QZGpixHnsuZ9T0I/YibpVwmX1HAXIBbAk+0CSPKfesvTYvT8W4DDZjAygtJdeWwZbPM2jvheesogHtEAbmPgNyrMWqAqdIlxBYXDkJm181r/kjsZ0q6loDaYbYS9xkxNgB9SrnhBbmNKnVbVp9WHVqjSBYSQ05HW7MeSwGOP2jECm27GkBgt2nTBM/3RysSirKTrTNt0d6dOrnI3Dyxo/eF7yOw4kSCGmXEAwzxvAMSNw7SZa0tHN1yfEAQFDwmixjIb7DScvJzh7Tz8AqrF9PcRSrFtGk11NhLX5s13Aw6CDAjTQqG7dIajezTCjP4XDcFoI+HyVbj+jTKgLqEUqusX6t8d2rD3j0VtxXibXYRuNpU5EA1G2Dg0nK4g6S0kE7RJ2TOFcTpVxLDcGHNNnNd4bH3JITuLKLAtbRDy85a7GyWOntONmuaQ6De+hFis7jOICkx0ntG7R3nUkcluuM4XrHOBHbguYeeX22n+2D4jxXlXFaQ654E2MEm8kamy1hQXm9gFWoXEucZJ5qw4Zhw9wabE+bddYOh8E3C4dhaZImbzrljUeferXgGBzOhpGfbNa+105So1xNjwbo4HUiGuOfUA3B1i5vuq7EUYY1w1IIP+TCPS4Wi4FiqtLKarfuZnDLDmEECJMd8nS0yq7Fs7VTlnzD/ACn6Iics9M0nDqmamDPMeEGIPeiIVX0ed2CDqbq3hbI5X1IoXQnkLoQSPASgJ0KIlx9kQOZQMD4lUuG/r9aKFjbFrbdkjwBIJ87KephO1mNzz+ia1hk2topZa6FBxqk1lMsBHWGDT3Li3tOgaezJvyUGAwrmU84cQQc1yLxeCIj0QvSGt1zppvh1CoAHc5b248Dkb5HmhsM+u7sOdLSZgCBMDX6LNpWdMZNRN3T4nTrUyyrAYbm5EQZmVg+mBDWNFJ5LXl19DDYs4ba+atW4Wq4ZbAbydfIKq6SYMtcxpg9mbd5P0VNKjODeXUoOHV308wa4t6ym5lrAtfLXB3MRmjkYRHRvCnru9ocRyk9j/wCx9Epo2AgWJ21mNT5e9aPgGFGZ7tuz6x/z6qJOkdF7DqtRtJgn2abZP9on3n4oDDVMM6hLnW0eQD7TpI23SdIK46uD99wEbmO18G+9TcJr0JqUnXLgyBckxp2uawibroWHQ2ux2HLD26YqOpuB0NOo0AjwVXxzg9TCgVaTiatMkPO9SlJIc4DUx80f0bcxtXE4cG7gHtBOsSCf9TVouNsD6dOpuAGuHMETcbwR71fH91eTHntbRUcO44yrQL7CoxpflPIDUfib4fks1xrhDa7WVKDWBxDs4EtzusRG2YjNymELjQaVY0Ke57F7AO2B2gz5Favo1TygB8HYxBH671pFbMZSpWjzWpgiLxcbG0EFEcPf2w6YIK3nSfC03YgloguaC61ibifGBeLqiwXR4dZ7WWfZgSAe8bjba8KpRNIc6rZosHi3VC5+fMHNDMjmODhpdrrAtkXsbkXTsXSu7vj6onCYMMbAAG5gQCYiYm2ilNGSnGNI5+SeUrBOGuc1wDQDOgO57u9aKDuI7jsstxKq5r2MuGl8SJzHSCANL7309NNgx2LkE5nG3eZ131KIy3QT4/0ZD0kJ5CTKtDnJISgJ0JQEDGFsqp4zVFNhY09p0iR37K6hZLH4OrWzkuFnRGgn78bkbTvdJlxK2KQDaVIBwbALtJO5bzE77qelTDTZMocOe1w0Wo4f0ekh9a24YDE/1H5KEi2yswGFfUPYaSN3GzR5nXyQfSvhmR7JMy3WIuCZ+IW9kAQBAFgBYDyWc6Vsz9WY0zD1y/RU+go6ZiBhvzV/hWBtFoGsX8SpKWCYwS67tuQ8t0I5zgxwBuTryB1+a5pu9HVFeTI9LKjjVaR7LJA8T7R84HoEvD2Dq57OhObMc0+C0bcA17IeJVO7o8GPIklpu3w7/DROO1RblRTUMZUFcVWOPWNiD4CNNwRbzXpT31K1DrKck+y9gi0doOaNTOZZvC8DysLo7TrjuG0d61/RNrqVLtB0zOm0ABJvehPaMg3hGZ+Z8ztDo9TBnyVnw95bUbTMkOEMO4cLhveCtbxDAMqdpoDX68gfEfNV+AosZmqPZLqcuE7ObpH1WsXZzz1pgHG+FVmS8iQTqLjz5cr9yAwONBOV9itf0UY4UJeSS5xN+WnvMoPjvRVtSalCGv1LNGu/p/Cfd4LQjT0wfC1wXBhNz7J5mJg9/wCvEsMhZLqahzMMtqNO9u0CCPBwI13+N3xGsavVUoN4dUtGm3r8AnZLiDYTBmvi31CTlbZvKBMfXzWpZTDQANAp6eHDWC0Hfnpp5JpCUVQTllRGQkhPhdCozokhLC6FxQUR1DsqjEOIORom/qSZ+JVxlUmHw4BzRcpAiDhfDQztvu8+jfzR9Qrsyge/YIKG1HgfqypeM1Jyt8SrasP1KoapzPJ228Apm9FQWyJwkBDOw07keBhHgWUTmrnxN7K2vQa0TneNpzWnunXyUT6P3iS/LrIbmA7rX81Y12gwDEJmHwQkw8j3xcLSMSJTJ8Fw0TmzEze5PzVtTZHfHehcFpBMkSCe8fkQp6gIuPNRiXkECoJQnF2HKS3eA71EfD3LnnMLWcPf3KTC1Q8ZXfqFUdMmW0P4RScSHkkNaMrRzAt6fNXbCUBQAAF+7REisAFuc5BxPhjanbAAqAQDsR+F3MfBZrD8NPWS+WuB2JBEciFsWO71FWoBxDtwk0UnRBSzZRngm9xvex8YiU4hOKRUQNISQnpIQIclhLCY4oGPa1JWqQJTQ9D13SgDhiZMbLn1Dsgq1KrI6tzAN8zHOJPcQ8Qo3VarINTK5sgEtDm5ZMAlpJkT3qbKUbJMVWcGkbm31Q72gAReQPWLhS1Rmd3LqbLzyUS2VHSFrU2iA38Imb3i+yg6uSp60hrncgT6BR4d5dTa86ua0+ZA+qVFX3IcXh2ZhlMgtBPc4zIspH0WjLlvLRmuLO3A/NQMJNZzNmspuB3lzqgP/wAB6osUlaREtdRaDGgEg9qQSJ7yDaOQZed+5GZRBPOBHMQZ+Xqg6VOHjvt6qLrK9QTSNNjAYBex1QvgwTDXtyjlcz3KWtlxdoIdSaAZdDhMDnAEecn4+bKTGlxeTEAnUDtbT3HuTaVR7pbUaGvb+Ey1zTo5s35gg6HnqnMbBSobdBDnnUaFMdVdoU6k37u2oUNfPmysDZ1LnSQOQDRqfMK09GbjbLDB1DujWuVNh2VgQXPplu4bTcD5E1DG2yPpvVEvRO9NSFICmIckSrkAPTSkzLs6QETgm5FI5wTQ4IAHr4ljCA4wTpYn4BA4uuKo6tkkGMzspAaNdSLnuCtnOsoh4JNWXFpbIOrsninZSCJTpRQrIX0ZBB3BHqq1mIaxgp1A5rmwPZcQ4CwLSAQZtbVXIK5zUUNS1TKzC0SXuqFpGYNaAbGGlxkjaS82QfH+MdRFOm3PWcAWtg5YLoBcRcTeOZGytsVjadMS8wPAlef08f13EjVvlzDJJNmgtj3CY5lRKVKkaccc3k1pG6wudzGue3K/7zeRB27rKThNM9RTkEHI2QRBFtwdEY4J7TZXRmpdUACmev0MdWbxac4tPNS1KSKBC5zZSobdg9MHzCidi3UnuLhLHQWuDMwaYALXAAkC0g6XKJLU8J0JSaB6XFWOOUESSbZI1km+VS3/AEEpcuBCdEt2PJSNTS4JA5AiYJVCHpesTArm44G2Zvu+qmZXaBJPpJ9wWDHGv5giKXFwdz6WXL9QjsfpZI2TMQHTE+hUH2+/te4KjbxowBmHgQErOIt1IB8yqXPEh8EjQU8W0mNzzc2FM4kahsdyzoxVMm8geI+BcnnH0RYyeXsfDMq9xeSVxvwX9Ooz8Q8yE54/C73j6rOOxFEmcxvzPwhOp4mjvJ/yR7i8h7b8F6aobq8fH4ITiONYGmaoAg2NpPiVDTxuFHd5OQvEcRhnxDpIn7ux1vAQ+ReQXGzLcSxjqsMZmDTYgmxPcJMD9QER9kDajBT0pZS42uS4ST5mPdsp8NTpNfJktEwN+6UY7EUoqZQRmy98EGZWVx8m7b6JGpGLbO496la8agrON42wj2YjuHxTHcZYdveI+S192PkwXDLwaN1Ug3b8UoxLdzHmFmqXHGTfK5saZvfqU+tx1k/u5E94/wCEPmj5GuGfg0D6zf4nuPyTW1x+KfAFZj9tgn2hP9IHySO4y/m39eSXvwD6efg1fX8p/wAUx2IPf6gLM/td4Htegn5IZ3FCdz6ape/Ef08mar7V4pPtQnWFkKmPdGp8iAg6/EH7X8XEfJJ+pXga9JJ9zeux7W3e5vqJ9E39r0Pxj0WBbiydR6X98Lvtf6lQ/UPsjRelKYUK+zmebj/tU9JlaO05nkfyRIojYep//KdkP4R/kfouXI9SiDqj+MDyRDG/zT5fmmZX7NZ/qP0XdvcN9I+JSsnEeGNm5cRyuB9VM1jBYA+p+qia524jwuo3PG2v9J+GYJWGAW14GnxP1Uoqd6EA5s/0j5ulOc1pF2jzAH1RYvbQfhaOd4a5waD946C3kphgWkkdc20QdWmWF0zM2iNNSFTAMH4fePg1WmBxWHaz96aftHPmbUcXU8oytpkNIa+c1yW6tvAITTJfH4CqnC2/xWgQ02IJMgkgDNsco137kyrwpuU/v2kibCATDM2ubSbfqFJRxOGDjIpGkcmUCk8VGt6xkhziBL8meSCZOh0U9HE4OP3vVud2JcyjVyQHVC7I3q5mOrB9kQZ7UEOq0Tg/xAuG6P03tDnV2Nuey8kkQ8t3d3T5hR1eA0XS3rGm4FzIItcZn3AmT4HXeXG43Dmm0U3U84qgmZa0sl/ZtTYSPYmwOkXkpuNq0clQNdRc7MzIWtqMcYa0PfcQ0Eg9i0Z3aw2S0NRl5K53C6dJxayDpdsAfHy9UoY081BUqvbfIzxJ/wCFHTxJP8P+1xWbsvBhZY0Li4a3/Xko2Qdcvlr7woqjG/jI8nfKEh4hIqA801z0JmExnJ8nfVOD4NpPm35vVCwJXVAf+D8lBUMd/qmVMQf4LvVg+a5uId+Bw7szf9yex4Eb4O59Pqm5f5j+vJSOxDvwOHmz6lM+0dx/yCdseJWilQdqXDvOb4kKF1FgPZeD5vJ9wCH/AGzXnVp7sjfoi8PxTESD1Qd4MK2xkv7LU/hhvDqDjeDB0IbymfacrNlK0dW8me4Wnu7kPh8TVeBLcvMOpwJPf3R707q3lxJLIiI6seMzrvEKWl3olsmqsc1tqBnaXanX8XJL9peYIpGL5pseQjtc0JRpVLyKbbWIEnz5G6fVrGCM7W22kag2s7ZLFfAEtbEQb0XHXQiYHmpG4rLEU3d/abyVcce4GHGmBeCTJIBtM3EjeSnHiTImaJMaFoF/FUoLwDDqnEGAhrmEE6S5msiIvrJCf9rbAOR8QT9z6+Kp242k49ttEGYsZtGaRceCJfxDDASG0yQDABa0FGHwS2kGPxTWi1N234d3R6pcPjmO9mm7cG7SRBuDe2qrHcdoNJDabfENkG1oKdTx1JzZDKZsTdvak7GCjD4/kaaZaPxbYkscQJ3btbdOGLYRGR4B5gcpvBnRBhwJGVlPf/w/ADXxnySV6jwfaa0d0Df+oJYr8YUHx373sNTJGu6a5lU+y624GTui/mq/7SJJdVpXgQSDETcSeajqVmlw/e0IGtwJ12m+yWIw80Kup6zwBYdvquZ1sey7uMMPh81XvDXSA+mAQRLYtIsRddJkQKcWvlPfsPJVgvgVvwWJD80GmTa/s+W6Fe9gcQaQ0H4Qbzvm8EPUxBb2gZi2UNJtm1An9BSsxri0mWjX2qd9J3PfHkjD9hZfBBi8K0sLhSaIu4kuAiCTGUk8veqsVKHJnrVKuhiezB6p0C/7v2reO6pK2KqG4w9No/oVY/llKf7nMxNIGQ1vk+oPkp/2i39VXf7UIHVf4DP8Cm9ZU/gt/wDbRin/AGVkN/adbYgeAA+SYcZUPtVX+RP1Qn2hx1jyAHwSRO3vWuK8GWafSyy7Lph9U+JE/FLhCadUPGewPjcEfdjnzVUWpwqP5n1TxJzXRo0TuKExIqWzRMnXxJ5bITF4yq50s6zvBFttPRVILt3gef0Tsk61B6/VKh5Lt/wsGYmvuwH+w/KEpqPOtEeQcD75Vd1I/GPIk/JOFNu73eQ+pSxRalL8YU6mN6bx5/Vqmw9ai1sFl5nM4vJi1uw9oi3Kb6oMGkN3+4JC6lzcPIH5oopyXcsW1mzIqN8CavzeFL18mZbHLrnRof8Azba+4Kn6umfv+rT8kx7GDR0+TvonX5Ri6/GW5pO7j3h1Q+8VYUeLAykCi1p5t62db+1UcPcqchvP3JQY0JCMWJSS7fySvYVGWlKMQ78TvX6pwxfMT6fEKtoeUH1I7pzKhUrcRSOrXDwI+YSl9M6SPEJX8DjV6kOpY8gwS4jxn3FT08fT6wE0yWSZEN0gxoBeYOqG6rkQUj8M7kfRKolOPJ5DmYphH/aI/wDUDQfMxCDNAkk5mATYdYw25aoZ2HKb1JTpdjO5rqn/ALCnUP5mnwc0/NJ1Luf+r80N1JXdSUV8hk3/AOSZqcuXIN10GKGtqlXJow5ftIk4LlyZzoexPKRcmbR6EZSBcuSMSZmia5cuQbv7UNCcVy5MiPQa5MXLkjNnFPYuXIHHqTBE4XdcuUSOyPQLaimaBcuWLNUQYpALlyqJR//Z",
    sinopsis:
      "En un futuro lejano, un joven noble hereda una misión peligrosa en un planeta desértico."
  },

  {
    id: 7,
    titulo: "Shrek",
    genero: "Animación",
    anio: 2001,
    calificacion: 4.3,
    director: "Andrew Adamson",
    poster:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTR7m96VHPL3GQ2ldn28N0XlCZmydbfh_1L_k-xXz267Q&s=10",
    sinopsis:
      "Un ogro solitario debe rescatar a una princesa y aprender que la apariencia no define a una persona."
  },

  {
    id: 8,
    titulo: "Mad Max: Fury Road",
    genero: "Acción",
    anio: 2015,
    calificacion: 4.7,
    director: "George Miller",
    poster:
      "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTExMWFhUWFx0aGRYYGBgbHhsaGh0dHSAXGx0bHyggGh0lGx0bITEjJSkrLi4uHSIzODMtNygtLisBCgoKDg0OGxAQGy8mHyUwLS0wLS0yLzUuLTAtKy0vNS0tLy0tLS0tLy0tNy0vLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAREAuAMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAGAAMEBQcIAgH/xABOEAACAQIEAgcDCAYGCAUFAAABAhEAAwQSITEFQQYTIlFhcYEHMpEUQlJyobHB8CMzgqKz0RUWYpKy4SQlNDVDc4PxU2N0wuIIF0RU0v/EABoBAAIDAQEAAAAAAAAAAAAAAAMEAAIFAQb/xAA3EQACAQIEAwYEBQQCAwAAAAABAgADEQQSITEFQVETYXGBsfAikcHRFDIzoeFCYnLxNFIGJDX/2gAMAwEAAhEDEQA/AMNpUqVSSKlVv0bwNi9cZLxujsMy9WFPuIzkHMe5dPw3q4Xoxa6m5fW4GttY6y2GZA6xeVWkBtSFBG0ZmCzNWCkwbVVU2MEKVEvSbo/bwt+3b/SZGYgu5UAgNGjKpA01O5EiRyqZiejNg37tmyzu1o+4rF2MXURpmygBCMT2S8QdYFTKZztlsD1gdSonxvDMIlrEP+mLW77WlysmQz1hQ6gmIUTU630Mti6Ve42UXbqScqAolkXA+ZgQBOhOogzpUyGQ1lG8CqVF1/opbRMQ5N5upuugWEQlQqsrHMcxnN81TpB0FRehnA7eLa8jh5VFKspELLqpJzaHQkxI0BjWKmU3tJ2y5S3IQbpUTP0bVcNdusbge3cuIQQiDsqhUlXYPrmmACdeUSfOE4DbGIxVu6Lpt2Q+UoO2+W4ttcsiCSWHxqZTO9qsG6VGx6CQuIPW5jZZ1AECf0aOhMnT38rDkY1rxc6GIl61be7dZS5S6UsuIYKWm2YIdZBUnlBMRUyGV7dOsDKVXPSPh6WcTk6t7VuARLLcJXYupBAMkHSdwRpsLLDdG8Ozsq3L9wLatuQttFab3VZMoztm0uEtMRESd6mUy3arYGClKiReBYdFxXW3bmbDOFJtojKQWKgglgd9xy8an/1JH6NDdGZmuCUyMSFspdUZS4C/PEsRup2IqZTOGsg3984GUqveG8CV8U9i47W1RLjF2UAjIhbMQCezpOhMjberzBdDbN1mW3cZwMPIcRla91ly3I/8ubZ9DNQKTI1ZV3gNSov450btW8OtwLdt3Fs23ctrbZ2OVkBOq3Jk5dRAO1CFcItLI4cXEVKlSrkvFSpUqkkcw99kbMhIMESO4ggjyIJHrTiYi4RkDOQFIygmMk5yI7pGY+U1HqfwJVN9EZ2RXJQsoBIDgpzIEawfCa4zZQTJa5jd+7eu5c5uPm93MWaeXZnfXTSmusuT1ktJPvydzv2u+KMsLwodWblvEXYwrYjqjktwhs21uy/a06y4So3/AAqN0l4J8mw1xVxa3bfylctsZe1KXAbzQSVIdGtxzyk7ESuuLps2W+vnO5LCCqu+RlE5JBbukSAT8SPWpD4zENAL3W6tCFBLHLbYQQO5Spjug0Vf1aVM9lcapstdIvRAhLKZwTnyqXliohsskdrucTgICXnfFgXMrWoVUYPaTq0QgAzlKlTIGggk71z8ZS6/sftO9mekErWMxIXIty8FcTlDPDKBlmAdQFWPJY5UuHY2/Y7VolesGWcoOYAgwJB+cBtRXi+jqWryIMU1s5byqbiJoiEl2hWMq9t7pXmSsc5AmeIOpTI7ZbLlrUgSssGnTnIB50SliFq6p9ZUoBuI9/TGLh1669Dt2xmbtMREN3kgRHh4V5HFMUGz9dezJK5iz9nNoRJOkx9nhT/BA+Iv5DcYF2a6SApLXER3EAwMxMga7tV7c4Nma6HxLIb1wG4l1VzuerF6ewWAOZjuV08dKlTEqhysdd51aV9hBe1j74Vwty5lMl4JjtjKxb6w013qXieOY24FVrtw5O2CBDDsxnLAZj2T7xJ0NW2D4CFVVbEhbd5Cb4U2yUZE61FPakTtrBBVtxEvXuA3BeHV3i1t7gwty5lUZbcWUBbw7cA8wkgwar+Mp3tf1nTQ5kQVxFy9eZS5uXGIhSxZiQCdFnUgGdvGvpxl6RcDMpyi2GUldEVVyyP7IXSjHhXA2K4Fjfu22YPlORGVFyXLkAgmWdgYUgmCSQOyDUJwy18ouYS5cuLbti46HIski3naQxEZlQAemg1qDFISQDtr8jac7ODylwpjMFJg7wSNQDyJ50+MZeU5usuAqd8zAgxl35HKAPIUVYPo+ly1btDGgWrjWrnVFe0pu3RZzn5uiGdGnwA1qVc6MW265bmKdRnz9q2AXbq3csFMOeYgDXXTQVU42kOZ+R+072cDLOKvKbjgsSVZHYgnRxlIJOxNL5beQC3ndQpVgpkQRLKQOXvsf2qL8R0dSGz4l1W6Q9x2tplY9Rdv50CtJCsMpAj3vShnpPYZMQVa6LrdXaJdSCDNpDAI0IE5QecVeliUqNlU8r85w07biRMfj7l5izsT2mIWTlXOSxCjZRJ2FRaVKjyoFoqVKlUnYqVKlUkion9mvD7eI4jYs3FVkYXJVhI0tOwkSJ1A50MUX+yZo4rhiP8Azf4Nyl8USKDkb5T6S9MXYDvmxf1K4dbDNcw1jlACnT7ZJP8AKs49q3R+xat2r2GsrbUHK+UHXMJVj3RBHqK1jF3AxK7x+e+qPpBwhcRhbtoxLKQp5Bl1X94D7a8zhMS6VFZ2J85sthVNM6aznmjf2ecDt3c9y9bDpIAzAxp3HmSTHhBoKyGYgzMRznuit+4BwQ2LFmwAGIUA5de0dWJ7u0Z8q3uI4js6dhuYnw6krVCzbCD/APVzCFoTDKTzBmNztty/Cs56YYQWsU6KgQZUOUbDMin8a3u7wshhKqQdCQJCAge9IHKsU9p9srxK+pjQW9v+WlKcNrmpVtfl9RGeI9n2Yygb/eC9tCSANSTAHia6JwPQjh/VL/o1p4AUvDHNGhMzvIPKsU6A4AXsfh0Puh858rYLwfAkAetdJW7RChVEFYAnnI318fuofGcQysqKSOekVwiAqSYF3ehuEz3B8ktATC6bacu/eawfGYZrdx7be8jFT5qYP2iuuMv500rmf2k4IWuI4jL7tx+sU94fUn+9mrnB8U1R2Rjy9JbGWZQyi1tNJG6D2bb46wt22LiEtKNsey2/rrW6WuhfDbiB1wduGG0EEd4md6w3oI0Y+wfFv8DV0zh7QCKFBURsdxOuvjVONVXSouUkacj3mTDKvZXI1v8AQTKrvRvDKApwLM/Z7IsucrSAQWEAiTvtA3ipVnopg20+TID7pBBkMN99DqCKt+n/AE3/AKNe0osC71qsZL5YykCPdM71D6FdN7fEbro2H6u4iZgc2eVBAInKsQWGmu5oWfEml2tjl63+l42telmyFRfwlXxb2b4W6pFmbV0yRBJUx3hjt5fbtWRY7CPauPauCHRipHiPvHjXRnSHi64fKSjMbpKyIldB38vCRrWFdN7/AFmMuPEZgp1I+iBOmnKn+F16z3D6i2l4tjaSZc6i2tpQ0qVKtmZkVKlSqSRUqVKpJFRT7MmI4lYI5C4fTqnk/ChajH2Qj/W2G8ru/wDyblL4s2oOf7T6S9I2dT3ibfYUFgx/GNeZHOpQsA9lhPmNKjW1a2/VtuBKn6S9/mNj6HnU+0cxidYn0OxPgdfhXjGM3nbmJkNzohPHykfo9cVpPu7/AMbSO6tmw9kKoA25nx5mviYVA3WQM+XLm5xMxPdOtPZxIHM8vKrYnFNXyg8hb+YmoCXA5m8QTX8/CudfbAscWxAHdb/hJXSCrXOHti/3tiPK1/CSneBn/wBk/wCJ9RF8SbqIQewDh2bE4i+f+HaCDzuNM/BD8a2nGnIrXInKpJ1jQanX7aBfYZw/q+HG4d711mH1VhAP7yt8aIfaBxDquG4x5j9CUB8bkIIPm1Ax7Gtjio6hfp6ztL4UvJlzGdZhFvKYD21fTWQ6gx9u9Yr7X8Frh74G6tbJ7spzKP3m+Fan7N8aL3CcMTrCG2R9RigHwANDPtX6PMcA9xSWW0y3IO4k5SdtoaaLgGFDFZD/ANiPpD3V8MwO+8zf2VqDxXCz9Jv8DV0qVrmv2Vf71wv1m/hvXS9E47+uv+P1MXw35ZiXt9H6XC/Uf71qs9h/+3XZ/wD1m/iWqtfb/wDrcL9R/vWqf2KpONujvwzfxLVP0v8A5nkfWVH/ACB4wy4zhox951QsLgUl5GUZVC5d+W/qfGsq6ZqRimBMnKv3Vu3E8LG430rEPaDYyYxlBJ7K6mO7wrnC6mZ7d3pNLHADCgDr94N0qVKtyYUVKlSqSRUqVKpJFRf7JT/rXDaT+t/g3KEKLfZTcy8Uw7dwufwrlL4v/jv/AIn0l6X5x4idBcQw2dCAYfdG0kNtpy8CNtaqeGY6MZetZyw+T2HWdSO3eVtv2auVxYYCATr3bedA97FKnH7abddgSnqHd/uSvH0ELhlPIE/LWaz3AF+s0K2Z8qrMTiv9YWLQP/415yP27Cr/AO6pQuhV30H5igqxxJW6QumYDq8ELYB+kXR4HiQwqlCkWLHoCfp9ZSoDp4zRwa5u9sX+9sR5W/4SV0XbfTlWFdMeHfKekYsxIe5YzD+wLaFv3Qad4KQldmPJT6iLYhdPObN0UwHyfBYeydDbsqG+tEt+8TVP7SeGX8ZgWsYYKzPcXNmbKAqy0zz7QWi1qZunKpgAQNBoBp9lZqVmWr2vO94TKCLQQ9mfR6/hMIbGKCEi6XSGzAKQunnnUmiPj2AF/DX7Ov6S0y8tMwIH2660lutcaJkDU/CCBoCe/mNanYe1AjTv9atVqs1TtDve8vkCrYzmv2Vr/rbCg75n0/6b10tWE8J4f1HSfq+XX3GHgty2zgegYVuhrQ4y4eqjDmoPzJgMONCO+Yv/APUB+twv1H+9apvYqP8ATbv/AKZv4lqjb2tdEcVjnsNh0VhbRw0uq6kgjffaq32b9B8ZgsQ968FVTaKQrKxMkHkY3UfkU7SxFIcPyZhmsdOe8iI3b3tDa+CZ/wC9Yj7Th/p7/UT7q3a7ZVcx2gSTG+ndr3VhPtPvh8e5HJEH7oqnCDesfD7R7Hm9DzHoYJ0qVKvSTEipUqVSSKlSpVJIqJvZwJ4hZ5aXP4T0M1O4KE64dZba6sN+jXNLHI2USuoGaJPdNCrLmpsO4+kvSbK4PQidBDinVg282oM6nMY0iJOmnL1oD6V8XVeN4K8s5QttToBo7urR6MaznFYK4XYrh3RSdEyuco5CTqdOdOcOsWgzriQySgyHKxhs6GSJEgoHX1rNpcPSld73uCLW6+cdrYvtBbLbW97/AMTpQcQE6LC7dx37qyjo5jBe43i7raQHywRHYdFWZ5QAazjiDWzduG0CLZdsgO4STlBknWI51a9Ffk2ZzirL3U7MBM+na1kowjsg9/PSqU+HihTZrk3FttfX6zhxYZ1sux67/tOgrfEyFzNAAGs/cef2Vn3B7qXeP3sQ47Nu2CJBPaKIg0H9ksayk4K5/wCG/wDdb+VSeG3LKC6L9oswX9GJZYcaZWg+7qWPOUUSATNk4atJWs1yRbQdfOSpigxF0tY33/idQWOJIumpHgDp8fGsG9snERe4k8bW7aIPhn+96CAJ0FSRw28drNz+438qthOGJhanaZr6W96wNasKg0W3n/EI/ZXj+p4lZMwGDqfIoYH94Cui2xeojmwEwT92w8fKuUL2AuoJa06jvKsB8SKsOkN/Bvk+SWmtwXzZixkSMm7N83y1J00BNcdw9cTVVgeVtBcaa66j6yUqwRbEe/lNc6SYMr0gwF+BF1GU+LW1cH91ko/t3SZMjfTXv5H8PWuU8DYLOOwzqCCwUEnLOu3hV50kwFtmX5Jh7qgZs36O9HvEr77MZCQDrE0CvwwMUQvsLXtppc666dJdK+W5y+/lOk1vSDEHl+fWvJYc65SGHyuq3Q1sEiSVMhSdWAMTzqfxbDW7twvgrV3qiB2SrHK2xEy0zo2/zvChngoDAZ/O2nrLDF/2/v8AxN06Yccs4a2xu3kknS2pUuYnZRr3DXQd9YBxfHm/ee6wguZjuGwHoABUnhfDyLqG/Yum0GGcBH930g/aKZ42LXWxZUqoVQQQw7UDMQGJYCe81pYLDJhzlGp68vCVr4h6qAHQA7SBSpUq0YnFSpUqkkVKlSqSRUU+zBZ4lYExpc1H/Kehair2XMBxTDzt+k/hPQMV+g/gfSFo/qL4j1m74mz9H3t9ecd/fpNZ37W+DFsKmIA/U3Cp+pciJ74YAD61aXhpfXUAQNvzNReJ8J6+xiMOQMt5SAe4xo3oYPpXk8NX7GqG6H9v9TarjNTKGcw1v/si4N1OBRyO3fJuGfo7KPLKM37VYjwvhL3cUmGgh2uBCPo6wxPlqfSupOH4IKiovZVQFAA5DSPgBWtxuuFprTHPX375TMwi2JYyBj+FhrTSBnhiI79Tr+Yrm3pTby4zEqdYvXB8GNdXrbGunnzrlfpuI4jjAOWJu/42oHA6hZ2HdL4uqWUA9Y70AwPXcQwyRIFwOfK32zPcIWK6VGHaAV+cBm1iNAJj0+6sb9gPD82Lv3+Vq0F/auNof7qMPWt0jWl+NV74jKOQ9dftOYY5Vg10w4G9/BYm1nmbTZVImSgDJrvOZdzO9cv12NXJvSfh3yfF4izEC3ddV+rJyn1WDTXAaxOeme4/f6QeJubEyy9nXG/kuOtOzFbdw9XcIj3HI1M8gwVj4Cuk0wZAhXPfqJ+6Jrkaum/Zpx/5Zw+1cJm5bHVXO8sgEHzZcreZNTjlEjLWXwP0ncNVI+GAvt14Serw+JjtKTacxuDLLr3Ah/jRX7LeGdRw2yNmuzdb9vb9wLV90u4CuNwtywxy5wsHmCrBgfsj1qwXDhYC6KBAHcBsKzHxmbCrR6E/Ll6n5RhVHaFpW8dxSWcNevXNVRCx8Y+aPEnQeJrl3GYlrlx7jmWdix8yZrYvbpxzJatYJDrcPWXPqLooPm0n9isXrc4NQy0TUP8AV6CLYqqWOXkIqVKlWzFYqVKlUkipVecY6PXLBGYSDzGvpVM9uKh0NjvBpVVxdTpPFE/s1/3lY/6n8J6GKJ/ZqP8AWNj/AKn8J6Bif0X8D6RnD/qr4j1nQ2BxOZYmY/OtTLZqnwcLEVMw2MDF1nVSB8QD/OvEuuptNqqljpAvh3RMLxu/iQP0ZUOumnWXJDweZGW4T9ceulpUCwBmPZg9+v5+FSFxH6QW+ZUt8CoH3n4VMRVaqRfkAPlFWUKLD3eShXKnTn/eON/9Td/xtXUGM4las63Lip5muZ+l9m3cxmIuriLRW7fuOsFj2WckEwsbGd61uAowdmINiIpX5TXPYTw7q+HtdO966xB/soAo/ez0WdMOMDCYVr8xFy0PRrqBv3C1A3RH2j8NwuFsYYs4NtAGYWzBYkliI5FiT61H9r/SSxisAi4W6t0G8GuZNSqhW98bqMxG/dQKmEq1cbeopylv2/1LBgE0mtXAeVc8+2zA5OJNcG162rftL2D/AIQfWt24Bj+uwmHvf+JZRz5lQT9tZp7fMAGs4fEAarcKHycSCfIp9tU4S5pYsKedx78xO1ReneYrWkew/j/U4xsMx7GIWB4XEkr5SuYeJy1m9Evs64W2Ix9kAkC2wusRyFsgj4tlHrXp8aivh3D7WitO+cWnTuYU1ccAEkwBqT+NVyYxiwWJnup3i+DF+xdsklRdtshYbjMCJHxrxGSxAM1mplZzR0y42cZjL1/XKzQg10RdFHhoJPiTVLT+OwjWrj2nEPbYqw8VMH7aYr31NVVAq7AaTHJJOsVKlSq85FSpUqkk266KrMbwqy+ptrMyYAEnx7/Wrh7dMm3WxUUNoRPE06jJqptB9+i+Gbe3r35j8KndFOjVm3jbToGDDNuZGqMO7uNWIs1Y8DtAX0P1v8JrOx1FBhahA/pb0M1MBja34mmuY6svqIUmyQfxqr4XdI4jibZmDh7LqPFS4Pr2l+yr1dSJNVFxsuPB+lay/efwrwuGpmqKg6KT8rGe4xeI7PJfmwHzl7YYncRQV026TPgb12+FBHU27VtSd7mZ3YxvAUpJo0Rtdtaw/wBp+LFzGsQ05FygabTuJ3OhNMcLwoquWcfCILFPlsBBbjPFr+JctduMZ1AOw5nSqjJrHOpQMmfx1/zqdh+ryMzRmGo56CdPGfuBmZ09QNBYRDeVBt6xB8vDzr3h2ZCGUkEcwYI/yq4xHCGBVgqw2UQZ7JPfynT7a84LBOHy5eyBOviNNTpsQf8AvULC0gE1T2UdPLdxEwV/LbuLpbOyuJnLGwMnQDloKI/ajgxd4biE2Kp1g/6ZzH7AR61gnEbHVMpQwRrpMr/Lv118BW9dCuMjG4IdZq0ZLkxqSIJgbSPKvPY/CihUXE09r3I745RbMChnNdbh7HOjZTCHENo2IOneLaSBp4tmPiMtZhg+iN975tMAiLcyvdZkRVUNlLnMw0+/TvFdBYbi2Etolq3dTKihVUEGFUQNvCmuL1m7MU056nwEphB8WbpJS2lsgu7AQNTyA/71LLVnftj40EwItq0nEOBofmJ2mI/ayD9qinoxxX5VhLN/m6At9caMP7wNYL4dhRFY8yR7/f5R7Pmcqd5lfts4H1eJTFKOzfEN4XEAHpKx8GrNq6T6d8E+WYK7aAlwM9v666gDzEr+1XNlel4TiO0oZTuunly990zsTTyvfrFSpUq04vFSpUqkk3qK+FPCn7V5WAI2ImRXx962MwO08MVIkYrUjh18W7iuwJAnQR3EU21g701cEUKqqVEZG2IIPnL0nam6uu4II8oSHpHa+g/wX/8Aqqq9jc10XVWIjTyn8DUCygPOplm2dgKzsPw3CYcllB1BBueRmnV4njMTZDrqCLDmNo5x3pN1GCxF4AhlARJjV30HPlvWD4rGNcdnOhbePw/Hv1rQOnnGEbDNh2BVi4dNZzAAzOgymIEaiQdTFZqpNL0qFKkLUtp6MPWZQa/5ucda4QIHnXq1cZdfz/nXla+nXyos7C+zxAXbIXJ2zzWNpmIkCTp37a1L4bhShRWWD7xHfEnv030M91UXRU5rgtct/wA+P8q0a/Y6pGYLLMsDkefwFK1Wy6CMU0zC8C8bw9nJbm4JkDaN9OUbE+FeOD497a3rNvMpZM4gwQ1uXgnuZRGnf50ZYHgdwWgtxRnOaCNoM6T3HvqPh+FWkuvlYF1zSDroFy89Ygj4+FUFQNoZY0iusAkxrNZvOWJICb7QXBnxM5dK8Pi3DA8yYnmTzMjaTO28c5pjD4ojDXLekNHfMghpHlBHLc0zgsS5KhcoK7T5bHv2+NNMsWpnlL2/i+vRbdwlltzlPZ7K6gxoNwNpGoGkgSZdDukSYLDvbNu7dQOWXqyjFQ0SCCVIE6+tZpavlhJADBuWmm5+4D18KJuG8QyDtQUaFYwYMd6k894G3KRMKV6CumRhpGKbkG8O/wD7n4YCepxHL5tvn+3yrIekV2zcxV29ZVhZds4VoBBbcaEjR5gTtFEPE+AYi7luYc9k/MzoCpPIZD2xzkj+dVNzgWOgg2yREEShqYTBLSJamDr4wOJxYvlqED5SoZ7EaI4M/SG3qN4phQk6lgO6AT+Aqbc4beXRrD+fVn7xUW6mX3kjzDD76c2gg4O0bv2gD2TIOx2r7UqzibYEFDz1D7TGokeB+NKpmPSW0l3gukT2xlVtKKuFdMFbS6DtoVjf+VZo2gFPYXEwa4rMmqmKPg6dXdZtvCuKWb0hG1G4Oh/zqwuYQGsi4JxYW71tmMAMJPh6VolzjwYg22Ur3gg1Y40gfFFn4TY6bR67h8pqd12W2QnvGFB7ixifTf0qsv44MNahYnFHKY1I1HmNRSj4nNp1jeDwC0nDHkYL9LrK32CoCOrB1POd4PPahFuFusyNe6jvhTAXofUZswBGwiMv97N9le7+BDu0c/xqy1MotNN0zNMybernhmKCgBlGg0Md9fekfBWs3AFUw3unvPcP5V6fhV1LPWPabIGCs2WQCdu1sCRtrrRyysBAWKtaFPRfo4XcXLc6a/GJHxozv4dwCGHhqOfOgLgXStbSW1XRgwneGBOoIPusNNdQRRri+LkW2uu3ZALTPvAev5ms+sHz6x6lYrpPeO4s1kWrVoIbjsFhjoEGpgbTA276reLYVUw17GH5oOVvpmGRWY6TLMIgDwqr4ilu6Xu2ruZzble9Mx5DwBMAfjTHTXijLw7C4JVys5NwrO1pCypmJ+kZbU/NB5iiU01ErVNgYDcOvQdCcx7IEAgg76k90iI7qi2tGHgfxqdhbb2HUuCocaEGQRsdQYOh1HiKb4hheruuo2mV74O358Kf0IvM+xDWMl4ZQbcsJMkjWNdB95mifA4QG24gEjVc22Zh2RpyygmPH0oSwFxi3VgTyA17x3eNaN0Y4I2QAatPYVZ1O0nXQDX075ilK7ZY5RUttH+jDgZE0tuj5Wk5pJ3BEAjQEg5jPiKnX/ebzP31N/q71fad1zaBjG40nNGh7QU/DuprFqMxj11nXnT/AApsxbSYP/kQtk116fWQWFNMveAamtaplrRrVZRPNK0h3OH2n962h81FKpLJFKqBafQQoq1OTH5zM34A5924jeTCmH4FiF+ZPiCP51WC6aft4+4uzMPU1i5XHOe4DJHbmEuqe0jD0NT+F4x7JJMgb6gj7Ode+EcRYnNevlLQOsAM7aTltqdM0c2hRzOwJLd9oiWxlw2EWB8+7ufGADB8c1VKsdCJcVAsm4a5ee2H6q6JGpyMB5zFWXCEJZjcU5bdtnYEEbCB+8RWdcS4z12ZrRu2iTJt9c7L45SeXgdR3kaC24Lx8WcFdt3LjtdxDDRmLZbdvbfbMxb+6KA2HsLiRagLSVZusUfFGAC5RR9WCW8u1HoamcE4iGuazHfVbg8VmwthRr27s+eef8JFeOFnLc2O+9SoosRD0tTeaJi+BW8VbysoII2/Edxqvu9FbyWWtdfe6g6m20FT5k/zq26NYsggTVj0u4siqtlBnuNrEjRRuTyikg7AWEZKjNtM14B0Ea/iSo92BE7xz+ImmemODuLfGHsAi2hgmRvIB1OygkanT3uQrXvZbb61GxB0Jlcp3EbfZXjjnRoXHFxJXNrKmGBOsz3Hupgu4s7awBVbmmNJi/CuAYl8T1N8G0FXNc6wlQEANzQqAAMoJnziYiq3inF/lOKvXYGVzCqeVm2NF/uKoPfr31qftDt/JsEc7s+JxH6EOYLG2O0y6bqFleZ/SVkHD8CxMoYcEZBI1O8D+1ExyMEbwC1TOcEmAeyEC8k2bwvpiJEbOijZWB5chK6V5zdfkIXMye8FBMCYkn60fGBvUziF9FRlsqYuvmkqVywAGyzv2gfATFV+CxptArlLW2/WJJGcdxI27QGvpqCRRKY35CCrG5FtSIX9H+CAOtwQI2AA/EfdWk8GwjAhx3QdtjvyMH1FAfRjFPdtWza7bhQGBYBg0Dc8yRBB568wwF1Y6XYi06Wuri45KqoKMpYCcjHMGTzKnyrNqI7VLTRR0WnmE0HiGGHyS4VMkxPuciNBE/fz9KDmtUQHiLXbQDW8jPDONfAgQfQ1Eax4VuYBuypWbxnjeMqK+IuvIW/cylIrwUNXBwwry1imjWvMn8OwlHet0qn3sL3Uqr2wlcjCc/UqIcP0I4g50wtweJEevfVhb9nOLPvNaXvBZpHmMtIZhPaWlBgVAtF2EnNCDuMDMT37r8aj9Yat+kXBmwa27bXkuFyzZUmBsJJPfHdyNUivUGuskeCDyPLz868XBm05/n4fd5V6Xvgx+NOaHT7eYmpJJXAcUUbqzIB1A8TH3iKL8NZzuAPz4UAwQZntLr6cqP8Aotig4DA6xt40pihYZhHMK1/hhjwOEYAnWKXSLhvXuroSjgZcwiY35+P40P42z1u7MpXYqSD9m9WXBeHYjMlzDYpWZDLWrjGfWdx5j1FIqt+es0bXuZf9BLOOwth3JR1AJM6TrAgDar25xpbVkNcbLlElidgBv5VXYDj+I/2W/hwt1j2Tb91lPqZMzrWfdOcS2KfqLLqUQyTmgO435QUXl3kE91FAJNidIs+lyRry75SdP+PHHXc8nIgi2PDmT3MYB8IAoewuM6y4huMFdWnrNu7tHUDNIEtodJJJ1qPxC1dtHJcUg+P51qJZvMjB1JVgZBG4NaNJbCI1mDwyxODFvCWLdwhUe6S0BtiVAcZoCkQ06QVPgDXnozggGYMAWDFTPhoQRTPEekrY5bSXQoddCZyhtoYDQZu8fkNYbHN1pyibo0yx+sA00iZfTl7w2196VULJYQeHcJU+KF13oyuGR8VaYgICxUNlYDQwjfOU/RYeR2qV0U4g4w9u9cW497EXcy5FYlba3FMEgQoYyZ5gAQdaGsVjr2Jv2bdo9gRsJBcDMS3lvqNSp3ijFEt2LD4jrrqtbYYfDrbcoCbYIZcplbha6XmVMBNNQZApbLrvyh65phrDbnaF1niAvXLhCMi2f0XagMbgJmQCRAXKQZ1zGQCtesteOCcPa3ZUXCS7EvcJiTcc5mJjxJqeUFWesFEx6qZ3NtpFWxNeXsVPtLXq+oiqDFALe8p+GvKlcPSqdZjalV6eJDqCIM4YCZZjOPi6QWe4WA95SLZ5bRqZHhGlVV/pCCY6geb3GJPiYigkcQeZn8xEVc8NVbmW5iJCLoqiZuGYEAakDYnTz0NdZWAuTNkWJ0E98dw13EsrpbXQQQkx3iSxif8AKotvopiSJVVJG6hhPl3fbR1w83m/V4a3bUaKX3H7Ke6Nhp5wavbOGuldbdp9NlZlJ/viP+3joscU6iwAhxRU6mY1dtXLD5biMh7jpP8AMeIr22JtsIIPnWo8U4cjDq7lslT/AMJyAQdpsudPjG+h1is16RcBfDNIlrRMKxEEH6Dj5rjuO/3Ho1xU0OhgqlIrqNpCvCOcjv8ADup7g/EjYuhxOWdR4fzqEhr2tvN7p17j/OmCARYwasQbia/wHH2rsMSCh7vxq6x/AcKym8txbYWSzFgAAOZJOlZx7Pn1azdUgDtKfDYj0Ovxrx7S8YouphrTyiKGfbV2EgEjcBI79WNZgwx7XKNus0ziR2YbnLzHdKc1xUssWVlyi6ZkqdCFGhWdpOu+gqnTiVlXyOGRlOuzDzG0gj76EsFeNtgG90mQe4/SHh3/AOVHTm0yh3to501KgmD+AYMPhTLUggiorFzrJeHsi9Kg2b9sgE22OVpgAlTGhJ55hvVNxXoIxBuYbMe+zcy5vJHHYuEdwg+FFfCcFYIDC1bB5AaaHy8OVWmIVrYL27U5twrPr6TrQVqlTpCMgbeYfjLHVtlnzBBBUjQqwIkEGpnD+JW0DF7fWNlyrJIXcElspBO0ROoJmtIxr4HGOPlthrdwdnrVJB8M4+dHjrA35UG9O+jIwjobSMbD+5eLh1c6GBCjJGvZMnxNPU6obTnFKlMjwlr0Q4sqC/jLoVX2UCQCXIPORmA82ImZmSa9EOFdcbOJuKVsWV/0S05BbtanE3Y0Nxyc3cJnuJGujPR92w9m5iLZW2pHVKYM7HM4O+blmGqgRoKNreMIWBtSOMxOU5U3nUoM4uYSXbw79aifLQDrpVAeIbQedSceoFstO/OsaoWZvih0wgG8sf6UJ1Ggr3f4zKe7y3oaweJzJ5aV4xt8hTNWCH8sN+GQG0JMBjFIltPGlQzg8Z2RSqdmy6CVbCoTMSwyAmTsOXf3D1o56JMqdtoNxucbD6I7oH53kIwaZmA8Z+H5j1oi+Vi0um/h91ehrjMLRSmbG80fCYgchVlZxi9x7oNZngumLJoLQuNz7UD49/2UVcL6QWr8KQbV3kj8/qNs33+FKCiV1Ihy99oVNdVxlYAp3H7wd58fWqTGWQso4z2zoCwmB9FxsVHdy3HMBy3f3E6049yQQZ1+/wDnXGW4kBtMy6S9GTaLXLKnqxq9uZKDvB+db/tbjn3mgNtW1VgD3Np8Dt91avjE92DuYRhyaCcp8GAPgD50E8f4EpD3rS5Mn660B7s/8RR9HvHL0MM0axOjQT0+YjHBMVcTwI55lMxqJ10IOx8gZ0i66TcNGJtC6gC3N9hr/ZJ5GfGPvoOOEuJ2khx3rr9m9XHC+MOFdHkQM0EHyPly+2isCNRBr0MpEJQm1dUgcxzU/SFXXDMQyTadpBWEPkSwT1Oo8/KpuGvdbErIjLBM6eKkQY8510mqPj+GNplAnL808tDyPhMa6iu3DaSfl1hhwji2XaiWzxwGOX2VnPRzHq0pcthnGqsWYSBuIBEkCT46ztREmMGkW1HoD99JVaeU2jqOGF4ZNfs3R+kRW/PeNaVrh1gKVGY2tCbbdtQQdGE6gjv1j4yN4fFnuA9B+FT7GNYc6ooIlm1lxiOP5LjZyMvVknmIUGD6iG9asMXwpXQPZIVyAWtzpPPKTtryOnltQbj7C3CDmgiNtiAZgj05VZYbi5BynQ5tp5bVxk0nAZL/AKDvqSxt5gNTlIaPMDX7KbxOLm2yjmKt7XGnU5h+TTluzhLrMpUq9wkq2YxMwdNonl40FqSkwmdhBjhzZVIO8154lf0qPj+KWbV44e7bupdUbSADP0Cw7Q8ahnFYRyVF+71gMG31ckeHcfSuiib3Ile2BN7yYb6gTtSqKtzBElPlXbBgqyEGfKa+1fIBveTtAZnnDUA1JgDc9w/P3ipOIxHyi4iWljkCYE/gD61Ad4GQd0N8Zj4gfCneH4bOwWQuYgZmkATzMAkCtQjmYigvpCnhvR+4Pmbf2l7p76JcJ0dlYuLofqn8apsJwB7RZM9ssmhgtvExqo1gj41fcKQxGmniPyaRY/FHVFhpJI4c1qAzMy/NbsyB3EzJHjy+6zt4NT9Ln3Uzbt5gylZB5VTPh7mGO02T4wU/+Phy5d1dgyt5YY3hisGQlhm2PZ7LiCGHqA3mKj/0cHy4lc4cLBAy9obFXHODTtgO5yqyysEEyQwOoYZQdQwg+DHvr1g7zC7fSUABDjQ6BgZOv9oGoNoM6QV4j0Vthutsm4ATJtApKa7gHdNttvKqvFcEzGc1wbL8w66nvHxo7YtmDBFiYmNp0J03nSR8aB+mePaziBlFsgjNGXnBU85A1kd3pRqVTMcp3g3SwvLngFsW0NvXKmmotklm1YGDI1IieUd9WGKsF0IgEwPmrErJkDNp8Y2mqm/0fx9knrFw4Iu20UAMc5uEDMp3gMwBJjWRyr5iVxll2XrsMbdn9Y+QkIpCsjmBJDqRkiZMjcUNcRRY3Vgff8jz03kym20ZwGF7SOLWW4QDORAcx3BO8aka699XV3h6IGYowaCQvZIJA2ETzB9KquCm9iLa4krbhmgoltmdmUiCoBjXbcaxqSYpf1j6y4LYywQTqkGVPukSYbSYqzVFclRrbeWQEecniz1khc6naOxMxOons+tJuCW8xk33I3l1215LAO1OYdbrLK21YTvA7vPaPwrxdTEIs9XPms9/dt/2oQbpDkHrJFvhFucoUjT+wN55g+FS24XbIGjhhordkERMeY8/TlVOL7G3BC5jGqrrp9+/2+FM2cO2VWykKZjvMEiPDUGicpS0vbFm5qCtzXxtn4AH8KnW7bG9ZYCArtMkDQgEyJ+kPsoWt3SNFV/GGyfvCD9tThcJYNDK4UgHNm9SCZJGms0NkB2l1JG8K+D4s3rK2r9pLoXslXCOCskAwZE9k1Du9DuE3Wk2msP32rjLB7wDKj0FDPRDhV9LpWIUWwoadCwZ2Mcz79Wly5lJEzlkGDzFVZnpn4TpOqqv+beC3TzocuCy3sLdvXZJLkwWSI7RZeWu5FKizAY8reViSRkIMd5K/wCfwr7XRjLCzrc++6dOEvqptMbnf871MwI51AWrDBGOdPvtFqe8J+Hz3nXxol4Y0aUK4K5tRFww9qs/XNHOUKcLbG8bCnnwildRIPKm8G0CphvCKMBAs2sGbKnCOUHuQWtHXsj51vTbQyPAHaKj4THFr93sCFRRGu8nx20U+tfOl/EFBReebN8BG/LeqDB40FjDNruEH3sdB+RrQyDONa8JsVji5kCIEaT9g/Hu+NZ50rw8XBdGoG+YAA66QNyPMme870bf0lZWEAlu7y598fVqh4rhGutJKieSgD4k9o/ZXabZWvKMpItJfBeJg5sS+LtdbeIuG25T9G6vdurkBudkZ1WJ17ckCmMTjFxKpbv4xJu4dFuXGQSMjJdUaNqwa46bbW4iZNUGK6MXBBt6699VePwV63HWAxy5ijLQolswAv8AaCJYaGHXydsLgS1vE2wbbXeqYIpcZmAGRsxysyjQgZhJgxJoEtYkqVuD3lYE+Y7/ADH3Grno5jc02Lp7F0ZfCeRHiDrVGEI6xCNRv4FTr+NFSmqk6amUJhy2LgAqTBErHcfzFfFuFmksYGpAP2VR4A3Hw6dWpYqzW4Gu/aX4dqvvyjIgtnulz4bmPu9RSzUrGwjy1Li5lqD1jEz2Bz2ny8N5+FSbV7rGyg6LzJ0A/PKqq7iiUVBCyoJ/siKfwqA5RrEZgnnpnfv8F8PDStuskv7+W2uVCC0TJ2A+mY5U1wxMwHaOdtWnceB0gaEacp0qrxd+X6se6sNcP0j81PAHQeU1JON6m292MxgmO9jJ/wA/IeFd7pU9ZfpdVXyoR1gWW1MlTsB46eY0jeoeIuGMykx9E6/HvqutWSyi8rliGzq3OG1KH6pMCpV++rjMPUePfVWPKWUc43a4gJg5ZJjY+m2242FKo1wjw/P5mlVCqmXzkTPlqZY94UqVaLxSnvCHA0TcJ3r5SpHnHOUKLFer1KlR+UXO8znpt+tT1+8V9sfq/T+dfaVVbYSc4zg/1bfnlTPDOdKlVesuZd4f8/GqjpZ+rPmK+0q5T/OPGSpsYL8P9+3/AM1fwr3jP19761z/AN1KlT8RhX7Pv1V364+6qHim7fU/GvtKlj+rGV/Tj93531BVpb94/wDLt/4npUqEdvfdC8/ffGrX6y79cfwzUzF7Dyf8KVKuf1e+knKSOjv+zjzr5h9n9fuFfKVDbcywjOJ5+VfKVKuiQz//2Q==",
    sinopsis:
      "En un mundo postapocalíptico, Max y Furiosa luchan por sobrevivir en una carrera frenética."
  }
];



let generoSeleccionado = "todos";
let textoBusqueda = "";
let favoritos = new Set();



const listaPeliculas =
  document.getElementById("lista-peliculas");

const entradaBusqueda =
  document.getElementById("entrada-busqueda");

const botonesFiltro =
  document.querySelectorAll(".boton-filtro");

const ventanaModal =
  document.getElementById("ventana-pelicula");

const cuerpoModal =
  document.getElementById("cuerpo-modal");

const botonCerrarModal =
  document.getElementById("boton-cerrar-modal");


function mostrarPeliculas() {

  const peliculasFiltradas = peliculas.filter((pelicula) => {

    const coincideGenero =
      generoSeleccionado === "todos" ||
      pelicula.genero === generoSeleccionado;

    const coincideBusqueda =
      pelicula.titulo
        .toLowerCase()
        .includes(textoBusqueda.toLowerCase());

    return coincideGenero && coincideBusqueda;
  });


  if (peliculasFiltradas.length === 0) {

    listaPeliculas.innerHTML = `
      <div class="tarjeta-pelicula mensaje-sin-resultados">
        <div class="informacion-pelicula">
          <h3>No se encontraron películas</h3>
        </div>
      </div>
    `;

    return;
  }


  listaPeliculas.innerHTML = peliculasFiltradas
    .map((pelicula) => {

      const esFavorita =
        favoritos.has(pelicula.id);

      return `
        <article class="tarjeta-pelicula">

          <img
            class="poster-pelicula"
            src="${pelicula.poster}"
            alt="${pelicula.titulo}"
          />

          <div class="informacion-pelicula">

            <div class="encabezado-pelicula">

              <h3 class="titulo-pelicula">
                ${pelicula.titulo}
              </h3>

              <button
                class="boton-favorito"
                type="button"
                data-id="${pelicula.id}"
                aria-label="Agregar a favoritos"
              >
                ${esFavorita ? "⭐" : "☆"}
              </button>

            </div>


            <div class="informacion-secundaria">

              <span>
                ${pelicula.genero}
              </span>

              <span>
                ${pelicula.anio}
              </span>

            </div>


            <div class="calificacion">
              ⭐ ${pelicula.calificacion}
            </div>


            <button
              class="boton-detalles"
              type="button"
              data-id="${pelicula.id}"
            >
              Ver detalles
            </button>

          </div>

        </article>
      `;
    })
    .join("");
}


function abrirModal(pelicula) {

  cuerpoModal.innerHTML = `
    <img
      src="${pelicula.poster}"
      alt="${pelicula.titulo}"
    />

    <div>

      <h2>
        ${pelicula.titulo}
      </h2>

      <p>
        <strong>Género:</strong>
        ${pelicula.genero}
      </p>

      <p>
        <strong>Año:</strong>
        ${pelicula.anio}
      </p>

      <p>
        <strong>Director:</strong>
        ${pelicula.director}
      </p>

      <p>
        <strong>Calificación:</strong>
        ⭐ ${pelicula.calificacion}
      </p>

      <p>
        ${pelicula.sinopsis}
      </p>

    </div>
  `;

  ventanaModal.classList.remove("oculto");
}



function cerrarModalPelicula() {

  ventanaModal.classList.add("oculto");
}



entradaBusqueda.addEventListener("input", (evento) => {

  textoBusqueda =
    evento.target.value.trim();

  mostrarPeliculas();
});



botonesFiltro.forEach((boton) => {

  boton.addEventListener("click", () => {

    generoSeleccionado =
      boton.dataset.filtro;


    botonesFiltro.forEach((botonFiltro) => {

      botonFiltro.classList.remove("activo");

    });


    boton.classList.add("activo");


    mostrarPeliculas();
  });
});



listaPeliculas.addEventListener(
  "click",
  (evento) => {

    const botonFavorito =
      evento.target.closest(".boton-favorito");

    const botonDetalles =
      evento.target.closest(".boton-detalles");


    if (botonFavorito) {

      const idPelicula =
        Number(botonFavorito.dataset.id);


      if (favoritos.has(idPelicula)) {

        favoritos.delete(idPelicula);

      } else {

        favoritos.add(idPelicula);
      }


      mostrarPeliculas();

      return;
    }


    if (botonDetalles) {

      const idPelicula =
        Number(botonDetalles.dataset.id);


      const pelicula =
        peliculas.find(
          (elemento) =>
            elemento.id === idPelicula
        );


      if (pelicula) {

        abrirModal(pelicula);
      }
    }
  }
);



botonCerrarModal.addEventListener(
  "click",
  cerrarModalPelicula
);


ventanaModal.addEventListener(
  "click",
  (evento) => {

    if (evento.target === ventanaModal) {

      cerrarModalPelicula();
    }
  }
);


mostrarPeliculas();